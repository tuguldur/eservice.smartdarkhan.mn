<?php
include APPPATH . '/modules/views/header_front.php';
?>

<div class="home-v2-main home-v3-main home-v4-main">
    <div class="container">
        <!--FAGs Section-->
        <section class="section">
            <div class="row">
                <div class="col-md-12">
                    <?php
                    if (isset($knowledge_group_name) && count($knowledge_group_name) > 0) {
                        $i = 0;
                        foreach ($knowledge_group_name as $row) {
                            $colorArr = array('deep-purple', 'info', 'green-span', 'orange');
                            $colorCode = array('673ab7', '0c5460', '4caf50', 'ff9800');
                            $article_data = GroupArticle($row['id']);
                            if ($i > 3) {
                                $i = 0;
                            }
                            ?>
                            <div class="facts_info_wrap">
                                <div class="box-heading <?php echo $colorArr[$i]; ?>">
                                    <a href="<?php echo base_url('groups/' . $row['slug']); ?>" style="color: #<?php echo $colorCode[$i]; ?> !important"><span><?php echo ucfirst($row['title']); ?></span></a>
                                </div>
                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="group-title-v4" style="color: #<?php echo $colorCode[$i]; ?> !important">             
                                            <a class="group-anchor-v4" href="<?php echo base_url('groups/' . $row['slug']); ?>" style="color: #<?php echo $colorCode[$i]; ?> !important">
                                                <i class="fa <?php echo $row['group_icon']; ?>"> </i>
                                            </a>
                                        </div>
                                        <?php if (isset($article_data) && count($article_data) > 0) { ?>
                                            <div class="group-title_details" style="border-top: 1px solid #<?php echo $colorCode[$i]; ?>;">
                                                <div class="article_list mt-10">
                                                    <div class="facts_info_wraps p-3 resp_p-0">
                                                        <a href="<?php echo base_url('articles/' . slugify($article_data[0]['title'])); ?>" >
                                                            <h6 class="mb-0"><?php echo $article_data[0]['title']; ?></h6>
                                                            <span class="mr-10"><i class="fa fa-calendar mr-10"></i><?php echo date('d-m-Y', strtotime($article_data[0]['created_on'])); ?></span>
                                                            <span><i class="fa fa-comment-o mr-10"></i><?php echo ArticleComment($article_data[0]['id']); ?></span>
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="mt-10">
                                                <a class="btn btn-info btn-sm white-text font-bold" href="<?php echo base_url('groups/' . $row['slug']); ?>">
                                                    <?php echo $this->lang->line('View_More'); ?>
                                                </a>
                                            </div>
                                        <?php } ?>
                                    </div>
                                    <?php if (isset($article_data) && count($article_data) > 0) { ?>
                                        <div class="col-md-4 border-left-1">
                                            <div class="article_list">
                                                <?php
                                                foreach ($article_data as $key => $value) {
                                                    if ($key > 0 && $key < 5) {
                                                        ?>
                                                        <div class="facts_info_wraps p-3 resp_p-0">
                                                            <a href="<?php echo base_url('articles/' . slugify($value['title'])); ?>" >
                                                                <h6 class="mb-0"><?php echo $value['title']; ?></h6>
                                                                <span class="mr-10"><i class="fa fa-calendar mr-10"></i><?php echo date('d-m-Y', strtotime($row['created_on'])); ?></span>
                                                                <span><i class="fa fa-comment-o mr-10"></i><?php echo ArticleComment($value['id']); ?></span>
                                                            </a>
                                                        </div>
                                                        <?php
                                                        if (($key + 1) < count($article_data)) {
                                                            ?>
                                                            <hr class="my-1">
                                                            <?php
                                                        }
                                                    }
                                                }
                                                ?>
                                            </div>
                                        </div>
                                        <div class="col-md-4 border-left-1">
                                            <div class="article_list">
                                                <?php
                                                foreach ($article_data as $key => $value) {
                                                    if ($key > 0 && $key > 5) {
                                                        ?>
                                                        <div class="facts_info_wraps p-3 resp_p-0">
                                                            <a href="<?php echo base_url('articles/' . slugify($value['title'])); ?>" >
                                                                <h6 class="mb-0"><?php echo $value['title']; ?></h6>
                                                                <span class="mr-10"><i class="fa fa-calendar mr-10"></i><?php echo date('d-m-Y', strtotime($row['created_on'])); ?></span>
                                                                <span><i class="fa fa-comment-o mr-10"></i><?php echo ArticleComment($value['id']); ?></span>
                                                            </a>
                                                        </div>
                                                        <?php
                                                        if (($key + 1) < count($article_data)) {
                                                            ?>
                                                            <hr class="my-1">
                                                            <?php
                                                        }
                                                    }
                                                }
                                                ?>
                                            </div>
                                        </div>
                                        <?php
                                    } else {
                                        ?>
                                        <div class="col-md-8 border-left-1">
                                            <i class="fa fa-exclamation-triangle" aria-hidden="true" style="color: red; padding-top: 50px; font-size: 40px; text-align: center; width: 100%;" ></i>
                                            <h4 class='no_record'> <?php echo $this->lang->line('No'); ?> <?php echo $this->lang->line('article'); ?> <?php echo $this->lang->line('found'); ?></h4>
                                        </div>  
                                    <?php }
                                    ?>
                                </div>
                            </div>
                            <?php
                            $i++;
                        }
                    } else {
                        ?>
                        <div class="col-md-12 border-left-1">
                            <i class="fa fa-exclamation-triangle" aria-hidden="true" style="color: red; padding-top: 50px; font-size: 40px; text-align: center; width: 100%;" ></i>
                            <h4 class='no_record'> <?php echo $this->lang->line('No'); ?> <?php echo $this->lang->line('article'); ?> <?php echo $this->lang->line('found'); ?></h4>
                        </div> 
                    <?php } ?>
                </div>
            </div>
        </section>      
    </div>    
</div>
<?php include APPPATH . '/modules/views/footer_front.php'; ?>