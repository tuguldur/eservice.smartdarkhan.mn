<?php
include APPPATH . '/modules/views/header_front.php';
$user_id = (int) $this->session->userdata('UserID');
$slug = $this->uri->segment(3);
$sort = $this->uri->segment(4);
$filter_by = $this->uri->segment(5);
if (!isset($sort) && $sort == '') {
    $sort = 'newest';
}
if (!isset($filter_by) && $filter_by == '') {
    $filter_by = 'all';
}
?>
<div>
    <div class="container">
        <div class="my-4">
            <div class="row breadcrumb_header_text">  
                <div class="col-md-6 mt-3 pt-1">
                    <a class="green_text" href="<?php echo base_url(); ?>"><b><?php echo $this->lang->line('Home'); ?></b></a>
                    <span class="separator">/</span>
                    <a class="current green_text" href="<?php echo base_url('community'); ?>"><span class="current-section"><?php echo $this->lang->line('Community'); ?></span></a>
                    <span class="separator">/</span>
                    <a class="current green_text" href="<?php echo base_url('community/topics/' . $slug); ?>"><span class="current-section"><?php echo ucwords($topic_title); ?></span></a>
                </div>
                <div class="col-md-6">
                    <form class="search pull-right">
                        <input type="search" class="form-control"  name="search" id="search" placeholder="<?php echo $this->lang->line('Search'); ?> <?php echo $this->lang->line('article'); ?> <?php echo $this->lang->line('title'); ?>" value="<?php echo isset($search) ? $search : ''; ?>">
                    </form>
                </div>
            </div>
        </div>  
        <hr>

        <div class="container">
            <div class="mt-3 community-header">
                <div class="row">
                    <div class="col-md-6 col-6">
                        <div class="page-header-item">
                            <h2 class="black-text"><?php echo ucwords($topic_title); ?></h2>
                        </div>
                    </div>
                    <?php if (isset($user_id) && $user_id > 0) { ?>
                        <div class="col-md-6 col-6 text-right">
                            <span class="page-header-item post-to-community">
                                <a class="btn btn-primary btn-large" role="button" href="<?php echo base_url("community-post"); ?>"><?php echo $this->lang->line('New') . " " . $this->lang->line('Post'); ?></a>
                            </span>
                        </div>
                    <?php } else { ?>
                        <div class="col-md-6 col-6 text-right">
                            <span class="page-header-item post-to-community">
                                <a class="btn btn-primary btn-large" role="button" data-toggle="modal" data-target="#PostModal"><?php echo $this->lang->line('New') . " " . $this->lang->line('Post'); ?></a>
                            </span>
                        </div>
                    <?php } ?>
                </div>
            </div>

            <?php if (isset($user_id) && $user_id > 0) { ?>
                <div class="follows_box">
                    <div class="community-header">
                        <div class="community-follow">
                            <div class="topic-subscribe" aria-haspopup="true">
                                <?php
                                if (isset($follwed) && $follwed != '' && $follwed = true) {
                                    $selected = "true";
                                } else {
                                    $selected = "false";
                                }
                                $post_comment = $only_post = "false";
                                if (isset($follwed) && $follwed != '' && $follwed = true && $child_follwed == true) {
                                    $post_comment = "true";
                                } elseif (isset($follwed) && $follwed != '' && $follwed = true && $child_follwed == false) {
                                    $only_post = "true";
                                }
                                ?>
                                <a class="dropdown-toggle" role="button" data-follower-count="<?php echo isset($total_follwer) ? $total_follwer : 0; ?>" aria-selected="<?php echo $selected; ?>" href="#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><?php echo isset($follwed) && $follwed == true ? $this->lang->line('Following') : $this->lang->line('Follow'); ?></a>
                                <div class="dropdown-menu" role="menu">
                                    <a class="dropdown-item" rel="nofollow" role="menuitem" data-method="post" aria-selected="<?php echo $only_post; ?>" href="<?php echo base_url('subscription/' . $slug . '/false'); ?>"><?php echo $this->lang->line('New'); ?> <?php echo $this->lang->line('posts'); ?></a>
                                    <a class="dropdown-item" rel="nofollow" role="menuitem" data-method="post" aria-selected="<?php echo $post_comment; ?>" href="<?php echo base_url('subscription/' . $slug . '/true'); ?>"><?php echo $this->lang->line('New'); ?> <?php echo $this->lang->line('posts'); ?> <?php echo $this->lang->line('and'); ?> <?php echo $this->lang->line('comments'); ?></a>
                                    <?php if (isset($follwed) && $follwed == true) { ?>
                                        <a class="dropdown-item" rel="nofollow" role="menuitem" data-method="post" aria-selected="false" href="<?php echo base_url('subscription/' . $slug); ?>"><?php echo $this->lang->line('Unfollow'); ?></a>                         
                                    <?php } ?>
                                </div>                    
                            </div>
                        </div>
                    </div>
                </div>
            <?php } else { ?>
                <div class="follows_box">
                    <div class="community-header">
                        <div class="community-follow">
                            <div class="topic-subscribe" aria-haspopup="true">
                                <a class="dropdown-toggle" data-toggle="modal" data-target="#PostModal" role="button" data-follower-count="<?php echo isset($total_follwer) ? $total_follwer : 0; ?>" aria-selected="false"><?php echo $this->lang->line('Follow'); ?></a>
                            </div>
                        </div>
                    </div>
                </div>
            <?php } ?>
            <div class="topic-header">
                <div class="btn-group">
                    <a class="dropdown-toggle" href="#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><?php echo $this->lang->line('Show'); ?> <?php echo isset($filter_by) ? $filter_by : ''; ?></a>

                    <div class="dropdown-menu" role="menu">
                        <a class="dropdown-item" aria-selected="<?php echo isset($filter_by) && $filter_by != '' && $filter_by == 'all' ? 'true' : 'false'; ?>" role="menuitem" href="<?php echo base_url('community/topics/' . $slug . '/' . $sort . '/all'); ?>"><?php echo $this->lang->line('All'); ?></a>
                        <a class="dropdown-item" aria-selected="<?php echo isset($filter_by) && $filter_by != '' && $filter_by == 'planned' ? 'true' : 'false'; ?>" role="menuitem" href="<?php echo base_url('community/topics/' . $slug . '/' . $sort . '/planned'); ?>"><?php echo $this->lang->line('Planned'); ?></a>
                        <a class="dropdown-item" aria-selected="<?php echo isset($filter_by) && $filter_by != '' && $filter_by == 'not_planned' ? 'true' : 'false'; ?>" role="menuitem" href="<?php echo base_url('community/topics/' . $slug . '/' . $sort . '/not_planned'); ?>"><?php echo $this->lang->line('Not'); ?> <?php echo $this->lang->line('planned'); ?></a>
                        <a class="dropdown-item" aria-selected="<?php echo isset($filter_by) && $filter_by != '' && $filter_by == 'completed' ? 'true' : 'false'; ?>" role="menuitem" href="<?php echo base_url('community/topics/' . $slug . '/' . $sort . '/completed'); ?>"><?php echo $this->lang->line('Completed'); ?></a>
                        <a class="dropdown-item" aria-selected="<?php echo isset($filter_by) && $filter_by != '' && $filter_by == 'answered' ? 'true' : 'false'; ?>" role="menuitem" href="<?php echo base_url('community/topics/' . $slug . '/' . $sort . '/answered'); ?>"><?php echo $this->lang->line('Answered'); ?></a>
                        <a class="dropdown-item" aria-selected="<?php echo isset($filter_by) && $filter_by != '' && $filter_by == 'no_status' ? 'true' : 'false'; ?>" role="menuitem" href="<?php echo base_url('community/topics/' . $slug . '/' . $sort . '/no_status'); ?>"><?php echo $this->lang->line('No'); ?> <?php echo $this->lang->line('status'); ?></a>
                    </div>
                </div>
                <div class="btn-group">
                    <a class="dropdown-toggle" href="#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><?php echo $this->lang->line('Sort'); ?> <?php echo $this->lang->line('by'); ?> <?php echo isset($sort) ? $sort : ''; ?></a>

                    <div class="dropdown-menu" role="menu">
                        <a class="dropdown-item" aria-selected="<?php echo isset($sort) && $sort != '' && $sort == 'newest' ? 'true' : 'false'; ?>" role="menuitem" href="<?php echo base_url('community/topics/' . $slug . '/newest'); ?>"><?php echo $this->lang->line('Newest'); ?> <?php echo $this->lang->line('post'); ?></a>
                        <a class="dropdown-item" aria-selected="<?php echo isset($sort) && $sort != '' && $sort == 'recent' ? 'true' : 'false'; ?>" role="menuitem" href="<?php echo base_url('community/topics/' . $slug . '/recent'); ?>"><?php echo $this->lang->line('Recent'); ?> <?php echo $this->lang->line('activity'); ?></a>
                        <a class="dropdown-item" aria-selected="<?php echo isset($sort) && $sort != '' && $sort == 'votes' ? 'true' : 'false'; ?>" role="menuitem" href="<?php echo base_url('community/topics/' . $slug . '/votes'); ?>"><?php echo $this->lang->line('Votes'); ?></a>
                        <a class="dropdown-item" aria-selected="<?php echo isset($sort) && $sort != '' && $sort == 'comments' ? 'true' : 'false'; ?>" role="menuitem" href="<?php echo base_url('community/topics/' . $slug . '/comments'); ?>"><?php echo $this->lang->line('Comments'); ?></a>
                    </div>
                </div>      
            </div>

            <ul class="posts-list striped-list list-inline inline-ul">
                <?php
                if (isset($topics_data) && count($topics_data) > 0) {
                    foreach ($topics_data as $key => $value) {
                        ?>
                        <li>
                            <div class="striped-list-item ">
                                <span class="striped-list-info">
                                    <a href="<?php echo base_url('community/posts/' . $value['post_slug']); ?>" title="Test" class="striped-list-title"><?php echo $value['post_title']; ?></a>
                                    <ul class="meta-group list-inline inline-ul">
                                        <li class="meta-data"><?php echo ucfirst($value['first_name'] . " " . ucfirst($value['last_name'])); ?></li>
                                        <li class="meta-data">
                                            <?php
                                            $date1 = date('Y-m-d H:i:s');
                                            $date2 = date('Y-m-d H:i:s', strtotime($value['post_date']));
                                            $datetime1 = new DateTime($date1);
                                            $datetime2 = new DateTime($date2);
                                            $interval = $datetime1->diff($datetime2);
                                            $time0 = (int) $interval->format('%y');
                                            $time1 = (int) $interval->format('%m');
                                            $time2 = (int) $interval->format('%a');
                                            $time3 = (int) $interval->format('%h');
                                            $time4 = (int) $interval->format('%i');
                                            $time5 = (int) $interval->format('%s');
                                            if ($time0 <= 0) {
                                                if ($time1 <= 0) {
                                                    if ($time2 <= 0) {
                                                        if ($time3 <= 0) {
                                                            if ($time4 <= 0) {
                                                                $main_time = $interval->format('%s Second Ago');
                                                            } else {
                                                                $main_time = $interval->format('%i Minute Ago');
                                                            }
                                                        } else {
                                                            $main_time = $interval->format('%h Hour Ago');
                                                        }
                                                    } else {
                                                        $main_time = $interval->format('%a Day Ago');
                                                    }
                                                } else {
                                                    $main_time = $interval->format('%m Month Ago');
                                                }
                                            } else {
                                                $main_time = $interval->format('%y Year Ago');
                                            }
                                            echo $main_time;
                                            ?>
                                        </li>

                                    </ul>
                                </span>

                                <div class="post-overview-count striped-list-count">
                                    <span class="striped-list-count-item">
                                        <span class="striped-list-number"><?php echo $value['total_vote']; ?></span>
                                        <?php echo $this->lang->line('votes'); ?>
                                    </span>
                                    <span class="striped-list-count-item">
                                        <span class="striped-list-number"><?php echo $value['total_comment']; ?></span>
                                        <?php echo $this->lang->line('Comments'); ?>
                                    </span>
                                </div>
                            </div>
                        </li>
                        <?php
                    }
                } else {
                    ?>
                    <div class="col-md-12 mt-5">
                        <p class="no_record"><?php echo $this->lang->line('No'); ?> <?php echo $this->lang->line('Record'); ?> <?php echo $this->lang->line('Found'); ?></p>
                    </div>
                <?php }
                ?>
            </ul>

            <section class="community-footer text-center py-3 my-5">
                <h6 class="black-text"><?php echo $this->lang->line('did_find'); ?></h6>
                <?php if (isset($user_id) && $user_id > 0) { ?>
                    <a class="btn btn-primary" role="button" href="<?php echo base_url("community-post"); ?>"><?php echo $this->lang->line('New'); ?> <?php echo $this->lang->line('Post'); ?></a>
                <?php } else { ?>
                    <a class="btn btn-primary" role="button" data-toggle="modal" data-target="#PostModal" ><?php echo $this->lang->line('New'); ?> <?php echo $this->lang->line('Post'); ?></a>
                <?php } ?>
            </section>

        </div>
    </div>
</div>
<?php
include APPPATH . '/modules/views/footer_front.php';
?>