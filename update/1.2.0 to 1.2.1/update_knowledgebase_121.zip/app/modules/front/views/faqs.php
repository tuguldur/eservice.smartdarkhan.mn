<?php
include APPPATH . '/modules/views/header_front.php';
?>

<div class="container">
    <div class="my-4">
        <div  class="breadcrumb_header_text">
            <a class="green_text" href="<?php echo base_url(); ?>"><b><?php echo $this->lang->line('Home'); ?></b></a>
            <span class="separator">/</span>
            <a class="current green_text" href="<?php echo base_url('faqs'); ?>">
                <span class="current-section"><?php echo $this->lang->line('FAQs'); ?></span>
            </a>
        </div>
    </div>  
    <hr>
    <div class="faqs_section">
        <div class="content">
            <div class="row">
                <div class="col-md-12">
                    <div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
                        <?php
                        if (isset($faqs) && count($faqs) > 0) {
                            foreach ($faqs as $key => $value) {
                                ?>
                                <div class="panel panel-default">
                                    <div class="panel-heading" id="heading_<?php echo $key; ?>" role="tab">
                                        <h4 class="panel-title">
                                            <?php
                                            if ($key == 0) {
                                                $selected = "true";
                                            } else {
                                                $selected = "false";
                                            }
                                            ?>
                                            <a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse_<?php echo $key; ?>" aria-expanded="<?php echo $selected; ?>" aria-controls="collapse_<?php echo $key; ?>">
                                                <?php echo $value['title']; ?>
                                                <i class="pull-right fa fa-plus"></i>
                                            </a>
                                        </h4>
                                    </div>
                                    <div class="panel-collapse collapse <?php echo isset($key) && $key == 0 ? 'show' : ''; ?>" id="collapse_<?php echo $key; ?>" role="tabpanel" aria-labelledby="heading_<?php echo $key; ?>">
                                        <div class="panel-body">
                                            <?php echo $value['description']; ?>
                                        </div>
                                    </div>
                                </div>
                                <?php
                            }
                        } else {
                            ?>
                            <div class="col-md-12">
                                <p class="no_record"><?php echo $this->lang->line('No'); ?> <?php echo $this->lang->line('Record'); ?> <?php echo $this->lang->line('Found'); ?></p>
                            </div>
                        <?php }
                        ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php include APPPATH . '/modules/views/footer_front.php'; ?>
