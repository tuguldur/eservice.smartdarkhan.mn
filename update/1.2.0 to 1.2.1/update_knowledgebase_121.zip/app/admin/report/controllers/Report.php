<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Report extends MX_Controller {

    function __construct() {
        parent::__construct();
        $this->load->model('model_agent');
        $this->authenticate->check_admin();
        $this->lang->load('basic', get_Langauge());
    }

    //show report page
    public function index() {
        
        $month = $this->input->post('month');
        $year = $this->input->post('year');
        if ($month != '' || $year != '') {
            if ($month != '' && $year != '') {
                $condition = "MONTH(created_on) = '$month' AND YEAR(created_on) = '$year'";
            } elseif ($month != '') {
                $condition = "MONTH(created_on) = '$month'";
            } elseif ($year != '') {
                $condition = "MONTH(created_on) = MONTH(CURRENT_DATE()) AND YEAR(created_on) = '$year'";
            }
        } else {
            $condition = 'MONTH(created_on) = (MONTH(CURRENT_DATE())) AND YEAR(created_on)';
            $month = date("m");
            $year = date("Y");
        }
        $data['title'] = $this->lang->line('Manage') . " " . $this->lang->line('report');
        $data['month'] = $month;
        $data['year'] = $year;
        $yeardata = $this->model_agent->getData("app_article_view", "MIN(YEAR(created_on)) as min,MAX(YEAR(created_on)) as max");
        $data['year_data'] = $yeardata[0];
        $daily = $this->model_agent->getData("app_article_view", "DATE(created_on) as created_on,COUNT(id) AS total", $condition, "", "", "DATE(created_on)");
        $data['daily_data'] = $daily;
        $monthly = $this->model_agent->getData("app_customer", "DATE(created_on) as created_on,COUNT(id) AS total", $condition, "", "", "DATE(created_on)");
        $data['customer_data'] = $monthly;
        $this->load->view('index', $data);
    }

    public function community_report() {
        $month = $this->input->post('month');
        $year = $this->input->post('year');
        if ($month != '' || $year != '') {
            if ($month != '' && $year != '') {
                $condition = "MONTH(created_on) = '$month' AND YEAR(created_on) = '$year'";
            } elseif ($month != '') {
                $condition = "MONTH(created_on) = '$month'";
            } elseif ($year != '') {
                $condition = "MONTH(created_on) = MONTH(CURRENT_DATE()) AND YEAR(created_on) = '$year'";
            }
        } else {
            $condition = 'MONTH(created_on) = (MONTH(CURRENT_DATE())) AND YEAR(created_on)';
            $month = date("m");
            $year = date("Y");
        }
        $data['title'] = $this->lang->line('Manage') . " " . $this->lang->line('report');
        $data['month'] = $month;
        $data['year'] = $year;
        $yeardata = $this->model_agent->getData("app_post", "MIN(YEAR(created_on)) as min,MAX(YEAR(created_on)) as max");
        $data['year_data'] = $yeardata[0];
        $daily = $this->model_agent->getData("app_post_view", "DATE(created_on) as created_on,COUNT(created_on) AS total", $condition, "", "", "DATE(created_on)");
        $data['daily_data'] = $daily;
        $monthly = $this->model_agent->getData("app_post", "DATE(created_on) as created_on,COUNT(created_on) AS total", $condition, "", "", "DATE(created_on)");
        $data['customer_data'] = $monthly;
        $this->load->view('community', $data);
    }

}

?>